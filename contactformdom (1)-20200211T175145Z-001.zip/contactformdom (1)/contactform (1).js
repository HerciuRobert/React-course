
document.querySelector('form').addEventListener('submit', handleSubmit);


function handleSubmit(e) {
    const requiredField = document.querySelectorAll('.js-required');
    const radio = document.querySelectorAll(name='gender');

    for(let i = 0; i < requiredField.length; i++) {
      const field = requiredField[i];
      if(field.value === '') {
        field.style.border = '1px solid #c00';
        field.addEventListener(
          'change', 
          () => {
            removeErrorState(field);
            showSuccessMessage(field);
          }, 
          { once: true }
        );
        e.preventDefault();
      }
    }

    if (field[i].value !== '') {
      showSuccessMessage(field);
    }

}

function removeErrorState(elem) {
  elem.style.border = '1px solid #afafaf'
}

function showSuccessMessage(){
    
    const i = document.createElement('i');
    i.classList.add('fas','fa-check-circle');

    const p = document.createElement('p');
    p.classList.add('success-message');
    let fname = document.querySelector('.fname').name;
    p.innerHTML = ' Thank you for contacting us, ';
    p.style.color = '#088e1a';
    p.style.padding = '5px';
    p.style.backgroundColor = '#9aedbf';
    p.style.borderRadius = '5px';
    p.style.fontSize = '1em';
    const form = document.querySelector('form');
    p.prepend(i);
    form.prepend(p);
    fname.append(p);
  }